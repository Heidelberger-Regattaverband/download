CREATE TABLE MetaData (
	MetaData_Key VARCHAR(32) PRIMARY KEY,
	MetaData_Value VARCHAR(32) NULL
)

INSERT INTO MetaData
	(MetaData_Key, MetaData_Value)
VALUES
	('PatchLevel', '3.0')