ALTER TABLE 
	Athlet
ALTER COLUMN
	Athlet_ExternID_A VARCHAR(11)
	
	
ALTER TABLE 
	Athlet
ALTER COLUMN
	Athlet_ExternID_B VARCHAR(11)
	

ALTER TABLE 
	Entry
ADD 
	Entry_HasManualLabel BIT NOT NULL DEFAULT 0


--- increase patch level
UPDATE 
	MetaData
SET
	MetaData_Value = '3.1'
WHERE
	MetaData_Key = 'PatchLevel'