--- create new column...
ALTER TABLE 
	Athlet
ADD 
	Athlet_ExternState_B TINYINT NULL

--- increase patch level
UPDATE 
	MetaData
SET
	MetaData_Value = '3.4'
WHERE
	MetaData_Key = 'PatchLevel'