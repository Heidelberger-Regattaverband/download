--- create new column...
IF NOT EXISTS(
	SELECT 
		* 
	FROM 
		sys.columns 
	WHERE 
		Name = N'Offer_Prize'  
		AND Object_ID = Object_ID(N'Offer')
)

BEGIN
	ALTER TABLE 
		Offer
	ADD
		Offer_Prize VARCHAR(128)
END

--- alter column definition

ALTER TABLE
	Entry
ALTER COLUMN
	Entry_LongLabel VARCHAR(512)

ALTER TABLE
	Entry
ALTER COLUMN
	Entry_ShortLabel VARCHAR(256)

--- increase patch level
UPDATE 
	MetaData
SET
	MetaData_Value = '3.5'
WHERE
	MetaData_Key = 'PatchLevel'