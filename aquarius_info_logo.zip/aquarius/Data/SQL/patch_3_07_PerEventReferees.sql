--- new x-table for per-event referees
CREATE TABLE EventReferee
(
	ER_Event_ID_FK INT NOT NULL
		CONSTRAINT FK_EventReferee_Event
		REFERENCES Event(Event_ID)
		ON DELETE CASCADE
		ON UPDATE CASCADE,
	ER_Referee_ID_FK INT NOT NULL
		CONSTRAINT FK_EventReferee_Referee
		REFERENCES Referee(Referee_ID)
		ON DELETE CASCADE
		ON UPDATE CASCADE,
	CONSTRAINT PK_EventReferee PRIMARY KEY CLUSTERED
	(
		[ER_Event_ID_FK] ASC,
		[ER_Referee_ID_FK] ASC
	)
	WITH (IGNORE_DUP_KEY = OFF)
)

--- increase patch level
UPDATE
	MetaData
SET
	MetaData_Value = '3.7'
WHERE
	MetaData_Key = 'PatchLevel'
