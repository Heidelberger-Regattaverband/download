--- change column type for comp's datetime to DATETIME to store seconds

ALTER TABLE 
	Comp 
ALTER COLUMN 
	Comp_DateTime 
	DATETIME