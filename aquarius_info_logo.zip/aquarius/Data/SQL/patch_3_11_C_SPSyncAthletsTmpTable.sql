ALTER PROCEDURE SyncAthletes
	-- Add the parameters for the stored procedure here
	@SyncOnly BIT = 0
AS
BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- variables
	DECLARE @Nation_GER_FK_ID INT


	-- var init
	SET @Nation_GER_FK_ID = (SELECT Nation_ID FROM Nation WHERE Nation_IOC_Code = 'GER')

	-- sync data
	UPDATE
		Athlet
	SET
		Athlet_FirstName = x_FirstName,
		Athlet_LastName = x_LastName,
		Athlet_Gender = x_Gender,
		Athlet_DOB = x_yob,
		Athlet_ExternState = x_state,
		Athlet_ExternID_A = x_ID,
		Athlet_Club_ID_FK = (SELECT Club_ID FROM Club WHERE Club_ExternID = x_ClubID)
	FROM
		#tmp_athletes
	WHERE
		#tmp_athletes.x_ID = Athlet_ExternID_A


	-- insert new data
	IF @SyncOnly = 0
	BEGIN
		-- delete data that is already synced
		DELETE FROM
			#tmp_athletes
		WHERE
			(SELECT
				COUNT(Athlet_ID)
			FROM
				Athlet
			WHERE
				Athlet_ExternID_A = x_ID) > 0


		-- insert new data
		INSERT INTO
			Athlet
			(Athlet_FirstName, Athlet_LastName, Athlet_Gender, Athlet_DOB, Athlet_ExternState, Athlet_ExternID_A, Athlet_Nation_ID_FK, Athlet_Club_ID_FK)
		SELECT
			x_FirstName,
			x_LastName,
			x_Gender,
			x_yob,
			x_state,
			x_ID,
			@Nation_GER_FK_ID,
			(SELECT Club_ID FROM Club WHERE Club_ExternID = x_ClubID)
		FROM
			#tmp_athletes
	END

END