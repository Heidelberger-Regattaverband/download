--- increase patch level
UPDATE
	MetaData
SET
	MetaData_Value = '3.14'
WHERE
	MetaData_Key = 'PatchLevel'