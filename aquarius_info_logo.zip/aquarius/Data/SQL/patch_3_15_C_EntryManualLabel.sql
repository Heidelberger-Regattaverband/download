-- Remove flag that indicates a manual label and replace it with
-- a reference to the actual manual label. If the reference is
-- NULL, the computed labels apply. Otherwise the label is blindly
-- used in the EntryLabel table without any further checks.

ALTER TABLE
	Entry
ADD
	Entry_ManualLabel_ID_FK INT NULL
CONSTRAINT
	FK_Entry_ManualLabel REFERENCES Label(Label_ID)

GO

-- Migration of old data.
-- In a previous change, the label table was populated with existing labels.
-- So there is definitively an ID for the label

DECLARE @entry_id INT
DECLARE @long_label VARCHAR(512)
DECLARE @short_label VARCHAR(256)

DECLARE man_lbl_cursor CURSOR LOCAL FOR
	SELECT Entry_ID, Entry_LongLabel, Entry_ShortLabel FROM Entry WHERE Entry_HasManualLabel = 1
	FOR UPDATE OF Entry_ManualLabel_ID_FK

OPEN man_lbl_cursor

FETCH NEXT FROM man_lbl_cursor INTO @entry_id, @long_label, @short_label
WHILE @@FETCH_STATUS = 0
BEGIN
	UPDATE Entry SET Entry_ManualLabel_ID_FK = (SELECT TOP 1 Label_ID FROM Label WHERE Label_Short = @short_label AND Label_Long = @long_label)
	FETCH NEXT FROM man_lbl_cursor INTO @entry_id, @long_label, @short_label
END

CLOSE man_lbl_cursor
DEALLOCATE man_lbl_cursor

-- Drop old column with a fucking default constraint... sigh
DECLARE @constraint_name NVARCHAR(256)

SELECT
	@constraint_name = constr.name
FROM
	sys.tables tbls
	JOIN sys.default_constraints constr ON constr.parent_object_id = tbls.object_id
	JOIN sys.columns cols ON cols.object_id = tbls.object_id AND cols.column_id = constr.parent_column_id
WHERE
	tbls.name = 'Entry' AND cols.name = 'Entry_HasManualLabel'

EXEC(N'ALTER TABLE Entry DROP CONSTRAINT ' + @constraint_name)

ALTER TABLE
	Entry
DROP COLUMN
	Entry_HasManualLabel
