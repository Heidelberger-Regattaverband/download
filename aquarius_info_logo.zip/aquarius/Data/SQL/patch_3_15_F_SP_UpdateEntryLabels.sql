ALTER PROCEDURE UpdateEntryLabels
	@EntryID INT,
	@TeamPrefix VARCHAR(8)
AS BEGIN

	DECLARE @round_from AS INT = 0
	DECLARE @round_to AS INT = 0

	DECLARE @force_skip AS BIT = 0
	DECLARE @first_update AS BIT = 1

	DECLARE @manual_label_id AS INT = (SELECT Entry_ManualLabel_ID_FK FROM Entry WHERE Entry_ID = @EntryID)

	IF @manual_label_id IS NOT NULL
	BEGIN
		-- Delete all other labels, if any.
		DELETE FROM EntryLabel WHERE EL_Entry_ID_FK = @EntryID AND EL_RoundFrom > 0
		IF EXISTS (SELECT EL_ID FROM EntryLabel WHERE EL_Entry_ID_FK = @EntryID AND EL_RoundFrom = 0)
			UPDATE EntryLabel SET EL_Label_ID_FK = @manual_label_id, EL_RoundTo = 64 WHERE EL_Entry_ID_FK = @EntryID AND EL_RoundFrom = 0
		ELSE
			INSERT INTO EntryLabel (EL_Entry_ID_FK, EL_Label_ID_FK, EL_RoundFrom, EL_RoundTo) VALUES (@EntryID, @manual_label_id, 0, 64)

		-- nothing more todo
		RETURN
	END

	-- There can be cases where an athlete is only valid for the entry, but does not participate in any competition.
	WHILE @round_from < 64
	BEGIN
		IF @force_skip = 1
		BEGIN
			SELECT @round_from = MIN(Crew_RoundTo) FROM (
				SELECT Crew_RoundTo FROM Crew WHERE Crew_Entry_ID_FK = @EntryID AND Crew_RoundTo > @round_from
				UNION
				SELECT Crew_RoundFrom FROM Crew WHERE Crew_Entry_ID_FK = @EntryID AND Crew_RoundFrom > @round_from
			) AS Stat
		END ELSE
		BEGIN
			SELECT @round_from = MIN(Crew_RoundTo) FROM (
				SELECT Crew_RoundTo FROM Crew WHERE Crew_Entry_ID_FK = @EntryID AND Crew_RoundTo > @round_from
				UNION
				SELECT Crew_RoundFrom FROM Crew WHERE Crew_Entry_ID_FK = @EntryID AND Crew_RoundFrom >= @round_from
			) AS Stat
		END

		SELECT @round_to = MIN(Crew_RoundTo) FROM Crew WHERE Crew_Entry_ID_FK = @EntryID AND Crew_RoundTo >= @round_from
		SET @force_skip = CASE WHEN @round_to = @round_from THEN 1 ELSE 0 END

		--- No other changed crew member found -> break.
		IF (@round_to IS NULL) OR ((@round_to = 64) AND (@round_from = 0))
		BEGIN
			SET @round_to = 64
			BREAK
		END	ELSE
		BEGIN
			---print 'update ' + CAST(@round_from AS VARCHAR) + ' -> ' + CAST(@round_to AS VARCHAR)
			EXEC UpdateEntryLabel @EntryID, @round_from, @round_to, @first_update, @TeamPrefix
			SET @round_from = @round_to
			SET @first_update = 0
		END
	END

	IF @round_from <> @round_to EXEC UpdateEntryLabel @EntryID, @round_from, @round_to, @first_update, @TeamPrefix
END
