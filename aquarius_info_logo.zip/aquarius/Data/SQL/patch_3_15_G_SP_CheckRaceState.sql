ALTER PROCEDURE CheckRaceStates
	@OfferID INT
AS BEGIN

	SET NOCOUNT ON;

	-- race meta data variables
	DECLARE @GroupMode INT
	DECLARE @ForceDriven BIT
	DECLARE @OldDriven BIT
	DECLARE @OldCancelled BIT

	SELECT
		@GroupMode = Offer_GroupMode,
		@ForceDriven = Offer_ForceDriven,
		@OldDriven = Offer_Driven,
		@OldCancelled = Offer_Cancelled
	FROM
		Offer
	WHERE
		Offer_ID = @OfferID

	DECLARE @TotalBoatCount INT

	-- cursor variables
	DECLARE @NumEntries INT
	DECLARE @NumClubs INT
	DECLARE @NumTeams INT
	DECLARE @NumCancelled INT

	-- return values
	DECLARE @Driven BIT
	DECLARE @Cancelled BIT

	-- initialization; get group mode of race to be analyzed
	SET @Driven = 0
	SET @Cancelled = 1
	SET @TotalBoatCount = (SELECT COUNT(Entry.Entry_ID) FROM Entry WHERE Entry_Race_ID_FK = @OfferID)

	-- ensure that no group values remain in ungrouped races
	IF @GroupMode = 0 UPDATE Entry SET Entry_GroupValue = 0 WHERE Entry_Race_ID_FK = @OfferID

	--- gather information about race groups
	DECLARE group_cursor CURSOR FOR
		SELECT
			COUNT(Entry_ID) AS Entries,
			COUNT(DISTINCT(Entry_OwnerClub_ID_FK)) AS OwnerClubs,
			SUM(CAST (Label_IsTeam AS INT)) AS Teams,
			SUM(CAST (CAST (Entry_CancelValue AS BIT) AS INT)) AS Cancelled
		FROM
			Entry
			JOIN EntryLabel ON EL_Entry_ID_FK = Entry_ID AND EL_RoundFrom = 0 -- or RoundTo = 64 ?!?
			JOIN Label ON EL_Label_ID_FK = Label_ID
		WHERE
			Entry_Race_ID_FK = @OfferID
		GROUP BY
			Entry_GroupValue

	--- iterate over cursor

	OPEN group_cursor

	FETCH NEXT FROM group_cursor INTO @NumEntries, @NumClubs, @NumTeams, @NumCancelled
	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @Driven = CASE WHEN @Driven = 1 OR @NumEntries > 1 AND (@NumClubs > 1 OR @NumTeams >= 1) THEN 1 ELSE 0 END
		SET @Cancelled = CASE WHEN @Cancelled = 0 OR (@NumEntries - @NumCancelled) > 1 THEN 0 ELSE 1 END
		FETCH NEXT FROM group_cursor INTO @NumEntries, @NumClubs, @NumTeams, @NumCancelled
	END

	CLOSE group_cursor
	DEALLOCATE group_cursor

	--- a race is maybe forced to be driven

	IF @Driven = 0 AND @ForceDriven = 1 AND @TotalBoatCount > 0
		SET @Driven = 1

	IF @ForceDriven = 1 AND @TotalBoatCount > 0 AND @NumCancelled < @TotalBoatCount
		SET @Cancelled = 0

	--- update race
	UPDATE Offer SET Offer_Driven = @Driven, Offer_Cancelled = @Cancelled WHERE Offer_ID = @OfferID

	--- return value (the last + 1 is used to indicate a successful return)
	RETURN  @OldDriven * 16 + @Driven * 8 + @OldCancelled * 4 + @OldCancelled * 2 + 1
END