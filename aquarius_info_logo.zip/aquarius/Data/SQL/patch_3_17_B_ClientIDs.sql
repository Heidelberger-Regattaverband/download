DECLARE @client_uuid UNIQUEIDENTIFIER
SET @client_uuid = NEWID()

MERGE MetaData WITH (SERIALIZABLE) AS Present
USING (VALUES ('Client:ID')) AS UpdateValue (MetaData_Key)
    ON UpdateValue.MetaData_Key = Present.MetaData_Key
WHEN NOT MATCHED THEN
    INSERT (MetaData_Key, MetaData_Value)
    VALUES ('Client:ID', SUBSTRING(CONVERT(varchar(255), @client_uuid), 25, 10));
