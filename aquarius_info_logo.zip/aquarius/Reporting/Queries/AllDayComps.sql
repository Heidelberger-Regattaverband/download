SET LANGUAGE GERMAN
SELECT 
	Comp_ID,
	Comp_Event_ID_FK,
	Comp_Race_ID_FK,
	Comp_Round,
	Comp_RoundCode,
	Comp_HeatNumber,
	Comp_Label,
	Comp_GroupValue,
	Comp_DateTime,
	Comp_State,
	Comp_Number,
	DATEPART(hh, Comp_DateTime) AS Comp_Hour,
	DATEPART(n, Comp_DateTime) AS Comp_Minute,  
	DATEPART(weekday, Comp_DateTime) AS Comp_WeekDay,
	CAST(Comp_Dummy AS INT) AS Comp_Dummy,
	CAST(Comp_cancelled AS INT) AS Comp_Cancelled,
	RMLap_QRText AS Comp_RuleText
FROM
	Comp
	LEFT JOIN Offer ON Offer_ID = Comp_Race_ID_FK
	LEFT JOIN RaceMode_Detail ON Comp_RMDetail_ID_FK = RMLap_ID
WHERE
	Comp_Event_ID_FK = %event%
	AND Comp_DateTime IS NOT NULL
	AND DAY(Comp_DateTime) = DAY('%day%')
ORDER BY
	Comp_DateTime