SELECT
	Offer_ID,
	Offer_RaceNumber,
	Offer_LongLabel,
	Offer_ShortLabel,
	Offer_Comment,
	Offer_EventDay,
	Offer_Distance,
	Offer_GroupMode,
	Offer_AgeClass_ID_FK,
	CAST(Offer_IsLightweight AS INT) AS Offer_IsLightweight,
	REPLACE(ISNULL(Offer_Fee, 0), ',', '.') AS Offer_Fee,
	CAST(Offer_Driven AS INT) AS Offer_Driven,
	CAST(Offer_Cancelled AS INT) AS Offer_Cancelled,
	BoatClass_NumRowers,
	CAST(BoatClass_Coxed AS INT) AS BoatClass_Coxed 
FROM
	Comp
	LEFT JOIN Offer ON Comp_Race_ID_FK = Offer_ID
	LEFT JOIN BoatClass ON BoatClass_ID = Offer_BoatClass_ID_FK
WHERE
	Offer_Event_ID_FK = %event% AND
	Comp_DateTime IS NOT NULL AND
	DAY(Comp_DateTime) = DAY('%day%')
--- SQL Server fuckup
GROUP BY
	Offer_ID,
	Offer_RaceNumber,
	Offer_LongLabel,
	Offer_ShortLabel,
	Offer_Comment,
	Offer_EventDay,
	Offer_Distance,
	Offer_GroupMode,
	Offer_AgeClass_ID_FK,
	Offer_IsLightweight,
	Offer_Fee,
	Offer_Driven,
	Offer_Cancelled,
	BoatClass_NumRowers,
	BoatClass_Coxed
ORDER BY
	MIN(Comp_DateTime)
