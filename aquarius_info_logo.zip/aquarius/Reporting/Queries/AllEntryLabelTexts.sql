SELECT DISTINCT
    Label_ID,
    Label_Short,
    Label_Long,
    CAST(Label_IsTeam AS INT) AS Label_IsTeam,
    Nation_IOC_Code
FROM
    Entry
    JOIN EntryLabel ON EL_Entry_ID_FK = Entry_ID
    JOIN Label ON EL_Label_ID_FK = Label_ID
    LEFT JOIN Club ON Club_ID = Label_Club_ID_FK
    LEFT JOIN Nation ON Nation_ID = Club_Nation_ID_FK
WHERE
    Entry_Event_ID_FK = %event%
