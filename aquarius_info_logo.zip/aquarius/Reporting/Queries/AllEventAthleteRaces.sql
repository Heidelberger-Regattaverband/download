-- ermittelt pro Sportler die Rennennummern des Events in denen er beteiligt ist
SELECT DISTINCT
	Crew_Athlete_ID_FK AS AID,
	Offer_RaceNumber AS Nr,
	Offer_ID AS ID,
	CAST(Offer_Driven AS INT) AS Driven,
	CAST(Crew_IsCox AS INT) IsCox,
	Offer_SortValue
FROM
	Crew
	LEFT JOIN Entry ON Crew_Entry_ID_FK = Entry_ID
	LEFT JOIN Offer ON Entry_Race_ID_FK = Offer_ID
WHERE
	Entry_Event_ID_FK = %EVENT%
ORDER BY
	Crew_Athlete_ID_FK,
	Offer_SortValue
