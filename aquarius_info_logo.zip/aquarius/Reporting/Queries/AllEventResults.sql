SELECT
	CE_Comp_ID_FK AS Comp_ID,
	Result.*
FROM
	Result
	LEFT JOIN CompEntries ON Result_CE_ID_FK = CE_ID
	LEFT JOIN Comp ON CE_Comp_ID_FK = Comp_ID
	LEFT JOIN Offer ON Comp_Race_ID_FK = Offer_ID
WHERE
	Offer_Event_ID_FK = %event%
ORDER BY
	CE_Comp_ID_FK,
	CE_ID,
	Result_SplitNr