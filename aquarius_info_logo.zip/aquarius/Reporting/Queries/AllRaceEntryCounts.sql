SELECT
	Entry_Race_ID_FK AS Race_ID,
	COUNT(Entry_ID) AS Entry_Count
FROM
	Entry
WHERE
	Entry_Event_ID_FK = %event%
GROUP BY
	Entry_Race_ID_FK
