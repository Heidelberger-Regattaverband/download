SELECT
    Crew_Pos,
    Crew_RoundTo,
    Crew_RoundFrom,
    Crew_Entry_ID_FK,
    Crew_Athlete_ID_FK,
    CAST(Crew_IsCox AS INT) AS Crew_IsCox
FROM
    CompEntries
    JOIN Comp ON Comp_ID = CE_Comp_ID_FK -- AND Comp_ID = %comp%
    JOIN Entry ON Entry_ID = CE_Entry_ID_FK
    JOIN Crew ON Crew_Entry_ID_FK = Entry_ID
        AND Crew_RoundFrom <= Comp_Round AND Crew_RoundTo >= Comp_Round
WHERE
    CE_Comp_ID_FK = %comp%
ORDER BY
    Crew_Pos, Crew_RoundTo DESC, Crew_RoundFrom DESC
