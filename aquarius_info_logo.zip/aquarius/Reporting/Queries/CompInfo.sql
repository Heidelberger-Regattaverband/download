SELECT
	Comp.*,
	RMLap_QRText AS Comp_RuleText
FROM
	Comp
	LEFT JOIN RaceMode_Detail ON Comp_RMDetail_ID_FK = RMLap_ID 
WHERE
	Comp_ID = %comp%
