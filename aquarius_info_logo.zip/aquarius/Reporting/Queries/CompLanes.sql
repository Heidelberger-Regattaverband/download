SELECT
	CE_ID,
	CE_Entry_ID_FK,
	CE_Lane
FROM
	CompEntries
WHERE
	CE_Comp_ID_FK = %comp%
ORDER BY
	CE_Lane