SET LANGUAGE GERMAN
SELECT
	YEAR('%day%') AS Year,
	MONTH('%day%') AS Month,
	DAY('%day%') AS Day,
	DATEPART(weekday, '%day%') AS WeekDay