SELECT
	Event.*,
	Club_Name,
	Club_Abbr,
	Referee.*,
	Nation_IOC_Code
FROM
	Event
	LEFT JOIN Club ON Event_Club_ID_FK = Club_ID
	LEFT JOIN Referee ON Event_HeadReferee_ID_FK = Referee_ID
	LEFT JOIN Nation ON Referee_Nation_ID_FK = Nation_ID
WHERE
	Event_ID = %event%
