SELECT
    Entry_Race_ID_FK AS Race_ID,
    Entry_GroupValue,
    COUNT(Entry_ID) AS Entries,
    COUNT(DISTINCT(Label_Short)) AS Clubs,
    CAST ((CASE WHEN (COUNT(DISTINCT(Label_Short)) > 1) OR (COUNT(DISTINCT(Label_Short)) > 0 AND MAX(CAST(Offer_ForceDriven AS INT)) > 0) THEN 1 ELSE 0 END) AS INT) AS GroupDriven,
    REPLACE(ISNULL(Offer_Fee, 0), ',', '.') AS Fee,
    REPLACE(CAST ((CASE WHEN COUNT(DISTINCT(Label_Short)) > 1 OR (COUNT(DISTINCT(Label_Short)) > 0 AND MAX(CAST(Offer_ForceDriven AS INT)) > 0) THEN 1 ELSE 0 END) AS INT) * ISNULL(Offer_Fee, 0) * (COUNT(Entry_ID) - SUM(CAST(ISNULL(Entry_IsLate, 0) AS INT))), ',', '.') AS GroupFee,
    REPLACE(SUM(CAST(ISNULL(~Entry_IsLate, 1) AS INT) * ISNULL(Club_Discount, 0))/100.0 * Offer_Fee, ',', '.') AS DiscountSum,
    SUM(CAST(ISNULL(Entry_IsLate, 0) AS INT)) AS NumLate,
    REPLACE(SUM(CAST(ISNULL(Entry_IsLate, 0) AS INT)) * ISNULL(Offer_Fee, 0) * 2, ',', '.') AS LateFee
FROM 
    Entry
    JOIN Offer ON Entry_Race_ID_FK = Offer_ID
    JOIN Club ON Entry_OwnerClub_ID_FK = Club_ID
    -- use entry labels since fees refer to the entry
    JOIN EntryLabel ON EL_Entry_ID_FK = Entry_ID AND EL_RoundFrom = 0
    JOIN Label ON Label_ID = EL_Label_ID_FK
WHERE
    Entry_Event_ID_FK = %EVENT%
GROUP BY
    Entry_Race_ID_FK,
    Entry_GroupValue,
    Offer_GroupMode,
    Offer_Fee
ORDER BY
    Race_ID,
    Entry_GroupValue
