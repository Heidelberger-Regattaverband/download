SELECT
    Crew_Pos,
    Crew_RoundFrom,
    Crew_RoundTo,
    Crew_Entry_ID_FK,
    Crew_Athlete_ID_FK,
    CAST(Crew_IsCox AS INT) AS Crew_IsCox
FROM
    Crew
    INNER JOIN Entry ON Crew_Entry_ID_FK = Entry_ID
WHERE
    Entry_Race_ID_FK = %race%
ORDER BY
    Crew_Pos, Crew_RoundTo DESC, Crew_RoundFrom DESC
