SELECT 
    Offer.*,
	BoatClass_NumRowers,
	CAST(BoatClass_Coxed AS INT) AS BoatClass_Coxed     
FROM
    Offer
	LEFT JOIN BoatClass ON BoatClass_ID = Offer_BoatClass_ID_FK
WHERE
    Offer_ID = %race%