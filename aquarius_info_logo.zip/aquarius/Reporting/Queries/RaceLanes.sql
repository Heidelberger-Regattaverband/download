SELECT
	CE_ID,
	CE_Entry_ID_FK,
	CE_Comp_ID_FK,
	CE_Lane
FROM
	CompEntries
	LEFT JOIN Comp ON CE_Comp_ID_FK = Comp_ID
WHERE
	Comp_Race_ID_FK = %race%	
ORDER BY
	CE_Lane