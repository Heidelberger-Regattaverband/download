/*
 * vim: shiftwidth=4 tabstop=4 expandtab cindent:
 */

const urlTime = '/data/time';
const urlMessage = '/generated/message.txt';
const urlEvent = '/data/event';
const urlSchedule = '/data/schedule';
const urlCompData = '/data/comp/{id}';
const classActiveNav = 'active';

const roundLUT = {'R': 'Hauptrennen', 'V': 'Vorlauf', 'H': 'Hoffnungslauf', 'Q': 'Viertelfinale', 'S': 'Halbfinale', 'F': 'Finale', 'L': 'Rangliste', 'A': 'Abteilung', 'T': 'Testrennen', 'Z': 'Zwischenlauf'};
const compStateLUT = {0: 'ohne Daten', 1: 'geplant', 2: 'gestartet', 3: 'fehlstart', 4: 'offiziell', 5: 'beendet', 6: 'Fotofinish', 7: 'Z7'};

const VIEW_TYPE_RESULTS = 'results';
const VIEW_TYPE_STARTLIST = 'startlist';
const VIEW_TYPE_SCHEDULE = 'schedule';

var viewState = {
    compIdx: -1,
    view: VIEW_TYPE_SCHEDULE,
};

var data = {
    eventID: -1,
    loading: false,
    pendingUpdate: null,
    compViewState: VIEW_TYPE_STARTLIST,
    comps: {
        list: [],
        current: null
    }
};

var indicator = null;
var wsNotify = null;

function onTimeReceive(transport)
{
    var time = transport.responseText.evalJSON();

    $('clock').innerHTML = time.h + ':' + (time.m < 10 ? '0' : '') + time.m + " Uhr";
    $('clock').classList.remove('error');
}

function onTimeComplete(request)
{
    if (request.readyState == 4 && request.status == 0) {
        $('clock').classList.add('error');
    }
}

function onMessageReceive(response)
{
    if (response.status === 200 && response.responseText.length > 0) {
        $('message').show().innerHTML = response.responseText;
    } else {
        $('message').hide();
    }
}

function onEventReceive(transport)
{
    var eventInfo = transport.responseText.evalJSON()[0];

    $('event').innerHTML = eventInfo.title + ', ' + eventInfo.venue;

    if (eventInfo.id != data.eventID) {
        data.eventID = eventInfo.id;
        data.comps.current = null;
        fetchSchedule();
    }
}


//-------------------------------------------------------------------
// Schedule

function fetchSchedule()
{
    $$('li.comp_display').each(function(i) { i.hide(); });
    $('comp').hide();
    indicator.show();

    new Ajax.Request(urlSchedule, {method: 'get', onSuccess: onScheduleReceive.bind(this)});
}

function scheduleColumnCallback(row, rowData)
{
    // highlight running comps (running, false start, finished) if (rowData.
    const comp_dt = new Date(rowData.datetime);

    row.insert(new Element('td').update(rowData.isDummy ? '' : rowData.no))
    row.insert(new Element('td').update(rowData.isDummy ? '' : comp_dt.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' })));
    row.insert(new Element('td').update(rowData.isDummy ? '' : comp_dt.toLocaleTimeString(undefined, { timeStyle: 'short' })));
    row.insert(new Element('td').update(rowData.isDummy ? rowData.Label : rowData.RaceNumber).writeAttribute('colSpan', rowData.isDummy ? 5 : 1))

    if (!rowData.isDummy) {
        row.insert(new Element('td').update(rowData.RaceShortLabel + (rowData.RaceComment ? ' ' + rowData.RaceComment : '')));

        if (roundLUT[rowData.RoundCode]) {
            row.insert(new Element('td').update(roundLUT[rowData.RoundCode] + ' ' + rowData.Label));
        }

        if (!rowData.isCancelled) {
            row.insert(new Element('td').update(compStateLUT[rowData.State]));
            //row.insert(new Element('td', { 'class': 'center'}).update(new Element('a', { href: '#' }).update('>>') ));
        } else {
            row.insert(new Element('td', { colSpan: 3 }).update('gestrichen'));
        }

        row.observe('click', function(e) { fetchComp(rowData.compID); } );
        row.addClassName('clickable');
    } else {
        row.addClassName('schedule-dummy');
    }

    return true;
}

function onScheduleReceive(transport)
{
    var o = transport.responseText.evalJSON();

    data.comps.list = o.list;
    data.comps.current = null;

    highlightNavLi($('menu_schedule')); 
    createTableFromJson(['LaufNr', 'Tag', 'Startzeit', 'RNR', 'Rennen', 'Lauf', 'Status'], data.comps.list, scheduleColumnCallback);
    indicator.hide();

    /* reset comp navigation */
    if (viewState.view !== VIEW_TYPE_SCHEDULE) {
        viewState.compIdx = -1;
        viewState.view = VIEW_TYPE_SCHEDULE;
        document.title = 'Zeitplan';
        //history.pushState(viewState, 'Zeitplan', '/schedule');
    }
    
    checkAndShowScrollbar();
}

//-------------------------------------------------------------------
// competition data receive

function buildAthleteElements(a, showClub, isLast, isCox)
{
    retval = new Element('div', { 'class': 'athlete' + (isCox ? ' cox' : '') + ((a && a.isTainted) ? ' tainted' : '') });

    if (isCox) {
        retval.insert(new Element('span', { 'class': 'cox_indicator' }).update('St. '));
    }

    if (!a) {
        retval.insert(new Element('span', { 'class': 'missing' }).update('N.N.'));
        return retval;
    }

    retval.insert(
        new Element('span', { 'class': 'name' }).update(a.firstName + ' ')
    ).insert(
        new Element('span', { 'class': 'lastName' }).update(a.lastName + ' ')
    ).insert(
        new Element('span', { 'class': 'yob' }).update('(' + a.yob + (showClub ? ',&nbsp;' + a.clubUltraAbbr : '') + ')' + (!isLast ? ',' : ''))
    );
       
   return retval; 
}

function buildCrewElements(startlist, entry, compInfo, root)
{
    crew = {};
    startlist.athletes.findAll(function(a) { return (a.crewID == entry.ID) && (a.Round <= compInfo.Round); }).each(function(a) { 
        var isTainted = crew[a.pos] !== undefined;
        crew[a.pos] = a; 
        crew[a.pos].isTainted = isTainted;
    });

    const numPositions = compInfo.numRowers + compInfo.isCoxed;
    for (var i = 1; i <= numPositions; ++i) {
        root.appendChild(buildAthleteElements(crew[i], entry.isTeam, i === numPositions, i > compInfo.numRowers));
    }

    return root;
}

function getResultStr(r)
{
    if (r) {
        var c = '<span class="bold">' + r.displayValue + '</span>';
        if (r.splitNr != 64) {
            c = c + '&nbsp;(' + r.rank + ')'
        }
        if (r.displayType == 'T' && r.rank > 1) {
            c = c + '<br/>+';
            m = Math.floor(r.delta / (1000 * 60));
            s = Math.floor((r.delta / 1000) % 60);
            z = Math.floor((r.delta % 1000) / 10);
            if (m > 0) { 
                c = c + m + ':' + ((s < 10) ? '0' : '');
            }
            c = c + s + '.' + ((z < 10) ? '0' : '') + z;
        }

        return c;
    } else {
        return '-';
    }
}

function compColumnCallback(row, rowData, startlist)
{
    var i, a = '';
    var comp = startlist.props;

    if (viewState.view === VIEW_TYPE_RESULTS) {
        row.insert(new Element('td', { 'class': 'rank' }).update(rowData.rank > 0 ? rowData.rank : ''));
    }

    row.insert(new Element('td', { 'class': 'lane' }).update(rowData.lane));
    row.insert(new Element('td', { 'class': 'bib' }).update(rowData.full_bib));
    row.insert(
        new Element('td').insert(
            new Element('div', { 'class': 'boatLabel' }).update(rowData.isTeam ? rowData.shortLabel : rowData.longLabel)
        ).insert(
            new Element('div', { 'class': 'boatComment' }).update(rowData.comment)
        ).insert(
            buildCrewElements(startlist, rowData, comp, new Element('div', { 'class': 'crew' }))
        )
    );

    if (viewState.view === VIEW_TYPE_RESULTS) {
        for (i = 1; i <= comp.numSplits + 0; ++i) {
            sid = 's' + i;
            row.insert(new Element('td', { 'class': 'result' }).update(getResultStr(rowData.results[sid])));
        }

        var fr = rowData.results['s64'];
        row.insert(new Element('td', { 'class': 'result' }).update(comp.State == 4 || (fr && fr.rtype != 'N') ? getResultStr(fr) : '...'));
    }

    return true;
}

function pushCompViewState(comp)
{
    var title = '';

    if (viewState.view === VIEW_TYPE_STARTLIST) {
        title = 'Startliste'
    } else if (viewState.view === VIEW_TYPE_RESULTS) {
        title = 'Ergebnis';
    }

    title = title + ' ' + comp.RaceShortLabel + ', ' + roundLUT[comp.RoundCode] + ' ' + comp.Label;
    document.title = title;

    //history.pushState(viewState, title, '/comp/' + comp.compID + '/' + viewState.view);
}

function buildCompUI()
{
    var c = data.comps.current;
    var comp = c.props;
    var headers = ['Bahn', 'StNr', 'Boot/Mannschaft'];
    var i, header;

    /* sort comp data and insert headers for result (if displayed) */
    if (viewState.view === VIEW_TYPE_RESULTS) {
        headers.unshift('Rang');
        for (i = 1; i <= comp.numSplits + 1; ++i) {
            headers.push((comp.distance / (comp.numSplits + 1) * i) + '&nbsp;m');
        }
        c.entries = c.entries.sortBy(function(e) { return e.resultSortValue; });
    } else {
        c.entries = c.entries.sortBy(function(e) { return e.lane; });
    }

    header = new Element('div', {'class': 'compHeader'}).insert(
        new Element('div', { 'class': 'left' }).insert(
            new Element('div', { 'class': 'bold' }).update('Re.&nbsp' + comp.RaceNumber + ', ' + comp.RaceShortLabel + (comp.RaceComment ? '&nbsp;'+ comp.RaceComment : '')+ ', ' + roundLUT[comp.RoundCode] + ' ' + comp.Label)
        ).insert(
            new Element('div', { 'class': 'left' }).update('Lauf ' + comp.no + ', Start: ' + comp.datetime.substring(0, 16))
        )
    ).insert(
        new Element('div', { 'class': 'right state state' + comp.State + (comp.isCancelled ? ' cancelled ' : ' ')}).update(comp.isCancelled ? 'gestrichen' : compStateLUT[comp.State])
    ).insert(
        new Element('div', {'class': 'break' })
    );

    createTableFromJson(headers, c.entries, compColumnCallback, { head: header, userData: c });

    if (c.withdrawals.length > 0) {
        let wdBlock = new Element('div', { 'class': 'withdrawals' }).insert(new Element('h4').update('Abmeldungen in Rennen ' + comp.RaceNumber));
        let list = new Element('ul');
        for (i = 0; i < c.withdrawals.length; ++i) {
            li = new Element('li');
            li.insert(new Element('span', {'class': 'bib'}).update(c.withdrawals[i].bib));
            li.insert(new Element('span', {'class': 'label'}).update(c.withdrawals[i].label));
            list.insert(li);
        }

        wdBlock.insert(list);
        $('data').insert(wdBlock);
    }

    /* set navigation to correct index */
    for (i = 0; i < data.comps.list.length; ++i) {
        if (data.comps.list[i].compID == comp.compID) {
            if (viewState.compIdx !== i) {
                viewState.compIdx = i;
                pushCompViewState(comp);
            }
            break;
        }
    }

    checkAndShowScrollbar();
}

function highlightCompViewState()
{
    if (viewState.view === VIEW_TYPE_RESULTS) {
        highlightNavLi($('menu_result'));
    } else if (viewState.view === VIEW_TYPE_STARTLIST) {
        highlightNavLi($('menu_startlist'));
    }
}


function onCompReceive(transport)
{
    var o = transport.responseText.evalJSON();

    if (o) {
        data.comps.current = o;
        data.comps.current.props = o.comp[0];
        data.comps.current.comp = null;
        /* assign result sort value and split results to boat */
        data.comps.current.entries.each(function(boat) { 
                boat.results = {};
                splits = data.comps.current.results.filter(function(s) { return boat.ID == s.ID; } );
                splits.each(function(s) { boat.results['s' + s.splitNr] = s });
                if (boat.results.s64) {
                    boat.resultSortValue = boat.results.s64.sortValue;
                    boat.rank = boat.results.s64.rank;
                } else {
                    boat.resultSortValue = 99999999 + boat.bib;
                    boat.rank = null;
                }
        });

        highlightCompViewState();

        $$('li.comp_display').each(function(i) { i.show(); });
        $('comp').show();

        buildCompUI();
    }

    indicator.hide();
    data.loading = false;
}

function fetchComp(compId)
{
    if (data.loading) {
        return;
    }

    if (viewState.view !== VIEW_TYPE_RESULTS && viewState.view !== VIEW_TYPE_STARTLIST) {
        viewState.view = data.compViewState;
    }

    cancelDeferredCompUpdate();
    data.loading = true;
    indicator.show();
    new Ajax.Request( urlCompData.replace('{id}', compId), { method: 'get', onSuccess: onCompReceive.bind(this) });
}


function createTableFromJson(header, body, columnCallback, options)
{
    var table = new Element('table', { 'class': 'data' });
    var tr = new Element('tr');
    var tbody = new Element('tbody');
    var i, length = body.length;

    header.each(function(e) { tr.insert(new Element('th').update(e)) });

    table.insert(new Element('thead').insert(tr));

    for(i = 0; i < length; ++i) {
        tr = new Element('tr');
        if (columnCallback(tr, body[i], (options && options.userData) ? options.userData : null)) {
            tbody.insert(tr);
        }
    }

    table.insert(tbody);

    $('data').childElements().each(function(e){e.remove()});

    if (options && options.head) {
        $('data').insert(options.head);
    }

    $('data').insert(table);

    if (options && options.foot) {
        $('data').insert(options.foot);
    }
}

//-------------------------------------------------------------------
// current comp stuff

// get the most current comp:
//   1. the first started / false start comp
//   2. the first scheduled 
//   3. the last unofficial/official/fotofinish comp
//   4. the first comp in schedule (whatever state it has)
function findCurrentComp(schedule)
{
    schedule = schedule.filter(function(c) { return (!c.isCancelled) });

    var comps = schedule.filter(function (c) { return (c.State == 2 || c.State == 3) });
    if (comps.length > 0) { return comps[0]; }
    
    comps = schedule.filter(function (c) { return (c.State == 1) });
    if (comps.length > 0) { return comps[0]; }

    comps = schedule.filter(function (c) { return (c.State == 4 || c.State == 5 || c.State == 6) });
    if (comps.length > 0) { return comps[comps.length - 1]; }

    if (schedule.length > 0) { return schedule[0]; }

    return null;
}

function findAndFetchCurrentComp(schedule)
{
    var c = findCurrentComp(schedule);
    
    if (c) {
        fetchComp(c.compID);
    }
}

function onCurrentCompClick()
{
    new Ajax.Request(urlSchedule, {
        method: 'get', 
        onSuccess: function(transport) {
            var o = transport.responseText.evalJSON();
            data.comps.list = o.list;
            findAndFetchCurrentComp(data.comps.list);
        } 
    });
}

//-------------------------------------------------------------------
// navigation

function onNextCompClick()
{
    for (i = viewState.compIdx + 1; i < data.comps.list.length; ++i) {
        if (!data.comps.list[i].isDummy) {
            fetchComp(data.comps.list[i].compID);
            break;
        }
    }
}

function onPrevCompClick()
{
    for (i = viewState.compIdx - 1; i >= 0; --i) {
        if (!data.comps.list[i].isDummy) {
            fetchComp(data.comps.list[i].compID);
            break;
        }
    }
}

function onCurrentCompReloadClick()
{
    fetchComp(data.comps.current.props.compID);
}

function highlightNavLi(e)
{
    $$('nav#main_nav ul li').each(function(e){ e.removeClassName(classActiveNav); });
    e.addClassName(classActiveNav);
}

function checkAndShowScrollbar()
{
    $('scrollbar').toggle(document.body.scrollHeight > document.documentElement.clientHeight);
}

function switchDisplayMode(newView)
{
    data.compViewState = newView;
    viewState.view = newView;
    highlightCompViewState();
    buildCompUI();
    pushCompViewState();
}

function cancelDeferredCompUpdate()
{
    if (data.pendingUpdate) {
        clearTimeout(data.pendingUpdate);
        data.pendingUpdate = null;
    }
}

function deferredCompUpdate(id)
{
    // defer update for at most 2 seconds, but at least 125 ms
    const timeout = Math.random() * 1875 + 125;
    cancelDeferredCompUpdate();
    data.pendingUpdate = window.setTimeout(fetchComp, timeout, id);
}

function onNotificationReceived(e)
{
    var msg = JSON.parse(e.data);

    if (!msg || !msg.type) {
        return;
    }

    if (viewState.view === VIEW_TYPE_SCHEDULE) {
        if (msg.type == 'schedule:change') {
            fetchSchedule();
            return;
        }
    } else if (data.comps.current && msg.type.startsWith('comp:')) {
        /* a comp is viewed */
        if (data.comps.current.props.compID != msg.compID) {
            return;
        }

        if (msg.type === 'comp:stateChange') {
            fetchComp(msg.compID);
        } else if (msg.type === 'comp:startlistChange' || msg.type === 'comp:resultChange') {
            deferredCompUpdate(msg.compID);
        }
    }
}

function onHistoryStatePopped(e)
{
    const oldState = e.state;
    
    if (oldState === null) {
        return;
    }

    if (oldState.view === VIEW_TYPE_SCHEDULE) {
        fetchSchedule();
    } else if (oldState.view === VIEW_TYPE_STARTLIST || oldState.view === VIEW_TYPE_RESULTS) {
        fetchComp(data.comps.list[oldState.compIdx].compID);
    }
}

// ------------------------------------------------------------------
// setup
function initInfoPoint()
{
    new Ajax.Request(urlTime, {method: 'get', onSuccess: onTimeReceive.bind(self)});
    new Ajax.Request(urlMessage, {method: 'get', onComplete: onMessageReceive.bind(self)});
    new Ajax.Request(urlEvent, {method: 'get', onSuccess: onEventReceive.bind(self)});
    
    new PeriodicalExecuter(function() { new Ajax.Request(urlTime, {method: 'get', onSuccess: onTimeReceive.bind(this), onComplete: onTimeComplete.bind(this) }) }, 5);
    new PeriodicalExecuter(function() { new Ajax.Request(urlMessage, {method: 'get', onComplete: onMessageReceive.bind(this)}) }, 30);
    new PeriodicalExecuter(function() { new Ajax.Request(urlEvent, {method: 'get', onSuccess: onEventReceive.bind(this)}) }, 60);

    //window.onpopstate = onHistoryStatePopped;
    document.observe('beforeunload', function() { if (wsNotify) { wsNotify.close(); } });

    $('nav_top').observe('click', function(e) { window.scrollTo(0, 0); e.stop(); });
    $('nav_up').observe('click', function(e) { window.scrollBy(0, -300); e.stop(); });
    $('nav_down').observe('click', function(e) { window.scrollBy(0, +300); e.stop(); });
    $('nav_bottom').observe('click', function(e) { window.scrollTo(0, document.body.scrollHeight); e.stop(); });

    $('nav_next').observe('click', function(e) { onNextCompClick(); e.stop(); });
    $('nav_current').observe('click', function(e) { onCurrentCompClick(); e.stop(); });
    $('nav_reload').observe('click', function(e) { onCurrentCompReloadClick(); e.stop(); });
    $('nav_prev').observe('click', function(e) { onPrevCompClick(); e.stop(); });

    $('menu_schedule').observe('click', function(e) { fetchSchedule(); e.stop(); });
    $('menu_result').observe('click', function() { switchDisplayMode(VIEW_TYPE_RESULTS); e.stop(); });
    $('menu_startlist').observe('click', function() { switchDisplayMode(VIEW_TYPE_STARTLIST); e.stop(); });

    indicator = $('indicator');
    indicator.hide();

    wsNotify = new WebSocket('ws://' + location.host + '/notify/', 'aqntfy');
    wsNotify.onmessage = onNotificationReceived;
}

// ------------------------------------------------------------------
// main
document.observe('dom:loaded', function() { initInfoPoint(); });
