--- drop old constraint...
ALTER TABLE 
	Result
DROP CONSTRAINT
	FK_Result_CompEntries


--- ...and recreate it with cascading updates/deletes
ALTER TABLE 
	Result	
WITH CHECK ADD CONSTRAINT 
	FK_Result_CompEntries 
	FOREIGN KEY	
		(Result_CE_ID_FK)
	REFERENCES 
		CompEntries (CE_ID)
	ON DELETE CASCADE
	ON UPDATE CASCADE


--- increase patch level
UPDATE 
	MetaData
SET
	MetaData_Value = '3.3'
WHERE
	MetaData_Key = 'PatchLevel'