--- add new column for progression rule text
ALTER TABLE 
	RaceMode_Detail
ADD 
	RMLap_QRText VARCHAR(64) NULL


--- add reference to the rule the comp was created by
ALTER TABLE 
	Comp
ADD 
	Comp_RMDetail_ID_FK INT NULL
CONSTRAINT 
	FK_Comp_RaceMode_Detail
	FOREIGN KEY	
		(Comp_RMDetail_ID_FK)
	REFERENCES 
		RaceMode_Detail (RMLap_ID)
	ON DELETE SET NULL
	ON UPDATE NO ACTION --- uhm, not nice

ALTER TABLE 
	Athlet
ALTER COLUMN
	Athlet_ExternID_A VARCHAR(16)

ALTER TABLE 
	Athlet
ALTER COLUMN
	Athlet_ExternID_B VARCHAR(16)


--- increase patch level
UPDATE 
	MetaData
SET
	MetaData_Value = '3.6'
WHERE
	MetaData_Key = 'PatchLevel'