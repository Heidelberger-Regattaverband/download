UPDATE 
	Offer 
SET 
	Offer_Splits = 0 
WHERE 
	Offer_Splits IS NULL

ALTER 
	TABLE Offer 
ADD 
	CONSTRAINT Offer_Splits_Default DEFAULT 0 FOR Offer_Splits 

ALTER 
	TABLE Offer 
ALTER 
	COLUMN Offer_Splits TINYINT NOT NULL