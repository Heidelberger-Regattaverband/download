--- set default fee to zero (0), not NuLL which causes #NaN
--- to appear in finance reports, closes #92
UPDATE Offer SET Offer_Fee = 0 WHERE Offer_Fee IS NULL

ALTER TABLE Offer 
	ALTER COLUMN Offer_Fee SMALLMONEY NOT NULL

ALTER TABLE Offer
	ADD CONSTRAINT DF_Offer_Offer_Fee DEFAULT 0 FOR Offer_Fee
