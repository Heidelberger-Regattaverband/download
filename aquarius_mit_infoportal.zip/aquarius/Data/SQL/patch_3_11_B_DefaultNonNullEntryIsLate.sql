--- entries are not late entries by default (and not in an undefined state)
--- the according default contraint was already present since 2011-04-01, 
--- but ensure non-null here
UPDATE Entry SET Entry_IsLate = 0 WHERE Entry_IsLate IS NULL

ALTER TABLE Entry
	ALTER COLUMN Entry_IsLate BIT NOT NULL