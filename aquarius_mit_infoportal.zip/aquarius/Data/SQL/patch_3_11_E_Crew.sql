-- add club column to materialize an athlete's club so the database
-- keeps the correct history even if the athlete table is updated
ALTER TABLE Crew ADD Crew_Club_ID_FK INT
ALTER TABLE Crew WITH CHECK ADD CONSTRAINT [FK_Crew_Club] FOREIGN KEY([Crew_Club_ID_FK]) REFERENCES Club ([Club_ID]) ON UPDATE CASCADE

-- flush to ensure that the column was created
GO

-- data migration: in two steps
--- 1. Use the entry owner for regular DRV clubs if the entry is not a team
UPDATE Crew SET Crew_Club_ID_FK = Entry_OwnerClub_ID_FK FROM Crew
	JOIN Entry ON Crew_Entry_ID_FK = Entry_ID
	JOIN Club ON Club_ID = Entry_OwnerClub_ID_FK
WHERE
	Entry_IsTeam = 0
	AND (Club_ExternID > 10000 AND Club_ExternID < 90000)

--- 2. For all other entries we use the athlete's club that is
--- currently stored in the database. This might be not correct anymore,
--- but we dont have any other data available to use.
UPDATE Crew SET Crew_Club_ID_FK = Athlet_Club_ID_FK FROM Crew
	JOIN Athlet ON Athlet_ID = Crew_Athlete_ID_FK
WHERE
	Crew_Club_ID_FK IS NULL

ALTER TABLE Crew ALTER COLUMN Crew_Club_ID_FK INT NOT NULL
ALTER TABLE Crew CHECK CONSTRAINT FK_Crew_Club
GO

-----------------------------------------------------------------------

-- store crew based on a per-round basis
ALTER TABLE Crew ADD Crew_Round SMALLINT NOT NULL DEFAULT(0)

-- flush again
GO

-----------------------------------------------------------------------

-- reset tainted crew members where original and new athlete are the same
-- (should only be the case in dev environment)
UPDATE Crew SET Crew_Tainted_Athlete_ID_FK = NULL WHERE Crew_Tainted_Athlete_ID_FK = Crew_Athlete_ID_FK

-- mark tainted crew members with (invalid) special round value
UPDATE Crew SET Crew_Round = 128 WHERE Crew_Tainted_Athlete_ID_FK IS NOT NULL

-- Insert records from crew members which were tainted.
-- The effect is that there are new rows with the overriden crew members.
-- Assume round = 64 which matches earlier assumptions.
INSERT INTO Crew (Crew_Pos, Crew_Round, Crew_Entry_ID_FK, Crew_Athlete_ID_FK, Crew_Club_ID_FK)
	SELECT Crew_Pos, 64, Crew_Entry_ID_FK, Crew_Athlete_ID_FK, Athlet_Club_ID_FK FROM Crew
		JOIN Athlet ON Athlet_ID = Crew_Athlete_ID_FK
	WHERE
		Crew_Round = 128
GO

-- Reset existing changed crew members to their original values.
-- Together with the above, we keep the original crew member records and only add new
-- records for changed athletes.
UPDATE Crew SET Crew_Athlete_ID_FK = Crew_Tainted_Athlete_ID_FK, Crew_Round = 0 WHERE Crew_Round = 128
GO

-- Remove tainted (i.e. original) athlete column from crew table.
ALTER TABLE Crew DROP CONSTRAINT FK_Crew_TaintedAthlet
ALTER TABLE Crew DROP COLUMN Crew_Tainted_Athlete_ID_FK
GO

-----------------------------------------------------------------------

-- add new column to mark coxes as such and get rid of the special
-- value (99) in the position
ALTER TABLE Crew ADD Crew_IsCox BIT NOT NULL DEFAULT(0)
GO

UPDATE Crew SET Crew_IsCox = 1 WHERE Crew_Pos = 99
UPDATE Crew SET Crew_IsCox = 0 WHERE Crew_Pos <> 99

UPDATE Crew SET Crew_Pos = BoatClass_NumRowers + 1 FROM Crew
	JOIN Entry ON Crew_Entry_ID_FK = Entry_ID
	JOIN Offer ON Entry_Race_ID_FK = Offer_ID
	JOIN BoatClass ON BoatClass_ID = Offer_BoatClass_ID_FK
WHERE
	Crew_Pos = 99
