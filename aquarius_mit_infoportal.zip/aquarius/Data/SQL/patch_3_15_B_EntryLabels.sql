-- Create a storage for unique boat labels. In addition, a table similar to
-- CrewMembers is created where the labels for an entry for its different rounds
-- are stored. This saves storage space but more imporantly it allows to save
-- the correct boat label for every round.

-- Table for unique labels, potentially associated with a club.

CREATE TABLE Label (
	Label_ID INT IDENTITY NOT NULL,
	Label_Long VARCHAR(512) NOT NULL,
	Label_Short VARCHAR(256) NOT NULL,
	-- Is this label for a team?
	Label_IsTeam BIT DEFAULT 0,
	-- The Club for which the label was created, in case IsTeam is 0.
	-- Note that Club = NULL does not imply Team = 1 -> why?
	Label_Club_ID_FK INT NULL,
	CONSTRAINT PK_Label PRIMARY KEY NONCLUSTERED (Label_ID),
	CONSTRAINT FK_Label_Club FOREIGN KEY (Label_Club_ID_FK)
		REFERENCES Club (Club_ID)
		ON DELETE SET NULL
		ON UPDATE CASCADE
)
GO

-- cross table to link labels with entries in their according round
CREATE TABLE EntryLabel (
	EL_ID INT IDENTITY NOT NULL,
	EL_Entry_ID_FK INT NOT NULL,
	EL_Label_ID_FK INT NOT NULL,
	-- similar round limits as for the crew, defaults
	EL_RoundFrom SMALLINT DEFAULT 0 NOT NULL,
	EL_RoundTo SMALLINT DEFAULT 64 NOT NULL,
	-- THINK: have multi_noc stored in the database
	EL_IsCrewClubMultiNOC BIT DEFAULT 0 NOT NULL,
	EL_IsClubMultiNOC BIT DEFAULT 0 NOT NULL,
	CONSTRAINT PK_EntryLabel PRIMARY KEY NONCLUSTERED (EL_ID),
	CONSTRAINT FK_EntryLabel_Entry FOREIGN KEY (EL_Entry_ID_FK)
		REFERENCES Entry (Entry_ID)
		ON DELETE CASCADE
		ON UPDATE CASCADE,
	CONSTRAINT FK_EntryLabel_Label FOREIGN KEY (EL_Label_ID_FK)
		REFERENCES Label (Label_ID)
		ON DELETE NO ACTION
		ON UPDATE CASCADE
)
GO

-- Data Migration
-- for dev only, not for distribution
-- DELETE FROM Label

INSERT INTO
	Label (Label_Long, Label_Short, Label_IsTeam, Label_Club_ID_FK)
SELECT DISTINCT
	Entry_LongLabel, Entry_ShortLabel, Entry_IsTeam, NULL
FROM
	Entry

-- for dev only, not for distribution
--UPDATE Label SET Label_Club_ID_FK = NULL
--GO

-- straight forward migration
UPDATE
	Label
SET
	Label_Club_ID_FK = Club_ID
FROM
	Label
	INNER JOIN Club ON
		TRIM(Club_Name) = TRIM(Label_Long) OR
		TRIM(REPLACE(Club_Name, 'e.V.', '')) = TRIM(Label_Long) OR
		TRIM(REPLACE(Label_Long, 'e.V.', '')) = TRIM(Club_Name) OR
		TRIM(REPLACE(Club_Abbr, 'e.V.', '')) = TRIM(Label_Short) OR
		TRIM(REPLACE(Label_Short, 'e.V.', '')) = TRIM(Club_Abbr)
WHERE
	Label_Club_ID_FK IS NULL
	AND Label_IsTeam = 0

-- Simple label migration, just use the stored labels for all rounds on existing entries.
-- This does not reflect current capabilites but keeps data as they are.

-- for dev only, not for distribution
--DELETE FROM EntryLabel

INSERT INTO
	EntryLabel (EL_Entry_ID_FK, EL_Label_ID_FK, EL_RoundFrom, EL_RoundTo)
SELECT
	Entry_ID, Label_ID, 0, 64
FROM
	Entry
	JOIN Label ON (Entry_LongLabel = Label_Long) AND (Entry_ShortLabel = Label_Short)

-- there might be some labels left of clubs that (slightly) changed their over the years
-- but we cannot derive their club in a reliable fashion (thanks to clubs that do own
-- entries without any own athlete).