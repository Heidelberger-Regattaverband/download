CREATE OR ALTER PROCEDURE UpdateEntryLabel
	@EntryID INT,
	@RoundFrom SMALLINT,
	@RoundTo SMALLINT,
	@IsFirst BIT,
	@TeamPrefix VARCHAR(8)
AS BEGIN
--  SP to update the label of a boat for a given range where no crew changes occur.
--  Call this SP only in a batch where all round labels are updated. such as UpdateEntryLabels
--  Note that the very first round range in a batch MUST start at RoundFrom = 0

	DECLARE @label_short VARCHAR(256)
	DECLARE @label_long VARCHAR(512)
	DECLARE @label_club INT

	DECLARE @is_team BIT
	DECLARE @is_crew_multinoc BIT
	DECLARE @is_club_multinoc BIT

	DECLARE @label_id INT
	DECLARE @entry_label_id INT

	-- compute required labels
	SELECT
		@label_long = CASE WHEN SUM(One) > 0 THEN TRIM(STRING_AGG(Club_Name, ' / ')) ELSE TRIM(STRING_AGG(Entry_Club_Name, '')) END,
		@label_short = CASE WHEN SUM(One) > 0 THEN TRIM(STRING_AGG(Club_Abbr, ' / ')) ELSE TRIM(STRING_AGG(Entry_Club_Abbr, '')) END,
		@is_team = CASE WHEN SUM(One) > 1 THEN 1 ELSE 0 END,
		@label_club = CASE WHEN SUM(One) = 1 THEN SUM(Crew_Club_ID_FK) ELSE NULL END
	FROM (
		SELECT DISTINCT TOP 16
			Crew_Club_ID_FK,
			MIN(Crew_Pos) AS ClubOrder,
			1 AS One,
			MIN(Club_Name) AS Entry_Club_Name,
			MIN(Club_Abbr) AS Entry_Club_Abbr
		FROM
			Crew
			JOIN Entry ON Crew_Entry_ID_FK = Entry_ID
			JOIN Club ON Entry_OwnerClub_ID_FK = Club_ID
		WHERE
			Crew_Entry_ID_FK = @EntryID
			AND Crew_RoundFrom <= @RoundFrom
			AND Crew_RoundTo >= @RoundFrom -- ignoring RoundTo here
		GROUP BY
			Crew_Club_ID_FK
		ORDER BY
			ClubOrder
		) AS CrewClubs
		JOIN Club ON Club_ID = Crew_Club_ID_FK

	-- fall back to owner labels when no athletes where provided
	IF @label_long IS NULL
	BEGIN
		SELECT
			@label_long = TRIM(Club_Name),
			@label_short = TRIM(Club_Abbr),
			@label_club = Club_ID
		FROM
			Entry
			JOIN Club ON Entry_OwnerClub_ID_FK = Club_ID
		WHERE
			Entry_ID = @EntryID
	END

	IF @is_team = 1
	BEGIN
		SET @label_long = CONCAT(@TeamPrefix, ' ', @label_long)
		SET @label_short = CONCAT(@TeamPrefix, ' ', @label_short)
	END

	-- Insert/Fetch ID of corresponding label
	MERGE Label AS lbl_target
	USING
		(SELECT @label_long, @label_short, @is_team, @label_club) AS lbl_source (Label_Long, Label_Short, Label_IsTeam, Label_Club_ID_FK)
		ON (lbl_source.Label_Long = lbl_target.Label_Long AND lbl_source.Label_Short = lbl_target.Label_Short
		AND lbl_source.Label_IsTeam = lbl_target.Label_IsTeam
		AND ((lbl_source.Label_Club_ID_FK IS NULL AND lbl_target.Label_Club_ID_FK IS NULL) OR (lbl_source.Label_Club_ID_FK IS NOT NULL AND lbl_source.Label_Club_ID_FK = lbl_target.Label_Club_ID_FK)))
	WHEN MATCHED THEN
		UPDATE SET @label_id = lbl_target.Label_ID
	WHEN NOT MATCHED THEN
		INSERT (Label_Long, Label_Short, Label_IsTeam, Label_Club_ID_FK)
		VALUES (@label_long, @label_short, @is_team, @label_club);

	IF @label_id IS NULL SET @label_id = SCOPE_IDENTITY()

	-- compute additional properties of label
	SELECT
		@is_club_multinoc = CASE WHEN COUNT(DISTINCT Club_Nation_ID_FK) > 1 THEN 1 ELSE 0 END,
		@is_crew_multinoc = CASE WHEN COUNT(DISTINCT Athlet_Nation_ID_FK) > 1 THEN 1 ELSE 0 END
	FROM
		Crew
		JOIN Club ON Crew_Club_ID_FK = Club_ID
		JOIN Athlet ON Crew_Athlete_ID_FK = Athlet_ID
	WHERE
		Crew_Entry_ID_FK = @EntryID
		AND Crew_RoundFrom <= @RoundFrom
		AND Crew_RoundTo >= @RoundFrom

	-- Delete every other label reference when this is the first update in a batch.
	-- Rationale: The first database entry with the boat labels is always kept after it has been initially created.
	IF @IsFirst = 1
	BEGIN
		DELETE FROM EntryLabel WHERE EL_Entry_ID_FK = @EntryID AND EL_RoundFrom > 0
		-- insert or update entry label associated with the crew in that round
		MERGE EntryLabel AS dst
		USING
			(SELECT @EntryID, @RoundFrom)
			AS src (EL_Entry_ID_FK, EL_RoundFrom)
			ON (src.EL_Entry_ID_FK = dst.EL_Entry_ID_FK AND dst.EL_RoundFrom = 0)
		WHEN MATCHED THEN
			UPDATE SET
				dst.EL_Label_ID_FK = @label_id,
				dst.EL_RoundFrom = @RoundFrom, dst.EL_RoundTo = @RoundTo,
				dst.EL_IsCrewClubMultiNOC = @is_crew_multinoc, dst.EL_IsClubMultiNOC = @is_club_multinoc
		WHEN NOT MATCHED THEN
			INSERT (EL_Entry_ID_FK, EL_Label_ID_FK, EL_RoundFrom, EL_RoundTo, EL_IsCrewClubMultiNOC, EL_IsClubMultiNOC)
			VALUES (@EntryID, @label_id, @RoundFrom, @RoundTo, @is_club_multinoc, @is_crew_multinoc);
	END ELSE
	BEGIN
		-- It is assumed that the previous call deleted all other labels
		INSERT INTO EntryLabel (EL_Entry_ID_FK, EL_Label_ID_FK, EL_RoundFrom, EL_RoundTo, EL_IsCrewClubMultiNOC, EL_IsClubMultiNOC)
		VALUES (@EntryID, @label_id, @RoundFrom, @RoundTo, @is_club_multinoc, @is_crew_multinoc)
	END
END
