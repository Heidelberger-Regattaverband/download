ALTER TABLE RaceMode ADD RaceMode_IsSystemMode BIT NOT NULL CONSTRAINT [DF_RM_IsSystemMode]  DEFAULT 0
GO

-- assume nobody has fucked up the delivered database
UPDATE RaceMode SET RaceMode_IsSystemMode = 1 WHERE RaceMode_ID <= 5