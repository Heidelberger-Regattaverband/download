-- In the default shipped database, the lower limits for senior age classes
-- are wrong w.r.t. the required extended licence state.
-- (usually affects 3 rows)
UPDATE AgeClass SET AgeClass_MinAge = 19
WHERE AgeClass_MinAge = 23 AND AgeClass_Abbr LIKE 'S%' AND AgeClass_AbbrSuffix = 'A'