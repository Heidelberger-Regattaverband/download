ALTER TABLE Event ADD Event_ScheduleCheckMode TINYINT NOT NULL CONSTRAINT [DF_Event_ScheduleCheckMode] DEFAULT 0
GO
