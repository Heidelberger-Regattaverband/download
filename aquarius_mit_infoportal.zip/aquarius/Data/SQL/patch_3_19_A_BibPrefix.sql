ALTER TABLE 
	[Entry]
ADD 
	Entry_BibPrefix CHAR(1) NULL