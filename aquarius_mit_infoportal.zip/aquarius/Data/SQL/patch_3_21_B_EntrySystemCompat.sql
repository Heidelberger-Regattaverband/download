 -- Extend space for external IDs
ALTER TABLE Athlet ALTER COLUMN Athlet_ExternID_A VARCHAR(16) NULL
ALTER TABLE Athlet ALTER COLUMN Athlet_ExternID_B VARCHAR(16) NULL

-- Add Column to hide athletes
ALTER TABLE Athlet ADD Athlet_IsHidden BIT NOT NULL DEFAULT 0

-- Support for future usage of UUIDs
ALTER TABLE Athlet ADD Athlet_ExternUUID UNIQUEIDENTIFIER NULL
GO

-- Delete all "German" athletes that are not used in any entry
DELETE FROM
	Athlet
FROM 
	Athlet
	LEFT JOIN Crew ON Crew_Athlete_ID_FK = Athlet_ID
WHERE
	Crew_ID IS NULL
	AND Athlet_ExternID_A LIKE 'DE-%'

-- Hide all remaining German athletes
UPDATE Athlet SET Athlet_IsHidden = 1 WHERE Athlet_ExternID_A LIKE 'DE-%'

-- Add support for UUID-based external entry IDs
ALTER TABLE [Entry] ADD Entry_ExternUUID UNIQUEIDENTIFIER NULL