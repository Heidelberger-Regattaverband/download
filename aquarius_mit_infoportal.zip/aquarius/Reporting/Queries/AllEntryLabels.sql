SELECT
    EL_Entry_ID_FK,
    EL_Label_ID_FK,
    EL_RoundFrom,
    EL_RoundTo,
    CAST(EL_IsCrewClubMultiNOC AS INT) AS EL_IsCrewClubMultiNOC,
    CAST(EL_IsClubMultiNOC AS INT) AS EL_IsClubMultiNOC
FROM
    Entry
    JOIN EntryLabel ON EL_Entry_ID_FK = Entry_ID
WHERE
    Entry_Event_ID_FK = %event%