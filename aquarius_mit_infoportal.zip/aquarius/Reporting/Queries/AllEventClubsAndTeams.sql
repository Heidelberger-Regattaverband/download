SELECT DISTINCT
	Club_ID,
	Club_City,
	Club_Name,
	Club_Abbr,
	Club_Discount,
	Club_ExternID,
	Label_Short AS Entry_ShortLabel,
	Label_Long AS Entry_LongLabel,
	CAST(Label_IsTeam AS INT) AS Team,
	Nation_IOC_Code
FROM
	Entry
	LEFT JOIN Club ON Club_ID = Entry_OwnerClub_ID_FK
	LEFT JOIN Nation ON Nation_ID = Club_Nation_ID_FK
	-- use labels from the entry
	JOIN EntryLabel ON EL_Entry_ID_FK = Entry_ID AND EL_RoundFrom = 0
	JOIN Label ON Label_ID = EL_Label_ID_FK
WHERE
	Entry_Event_ID_FK = %event%
ORDER BY
	Team,
	Club_City, 
	Club_Name, 
	Entry_ShortLabel
