SELECT
	Crew_Pos,
	Crew_RoundTo,
	Crew_RoundFrom,
	Crew_Entry_ID_FK,
	Crew_Athlete_ID_FK,
	CAST(Crew_IsCox AS INT) AS Crew_IsCox
FROM
	Crew
	LEFT JOIN Entry ON Crew_Entry_ID_FK = Entry_ID
WHERE
	Entry_Event_ID_FK = %event%
ORDER BY
	Crew_Pos, Crew_RoundTo DESC, Crew_RoundFrom DESC
