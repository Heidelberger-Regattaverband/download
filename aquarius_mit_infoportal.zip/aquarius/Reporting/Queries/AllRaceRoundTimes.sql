SELECT
	Comp_Race_ID_FK,
	Comp_Round,
	DATEPART(WEEKDAY, MIN(Comp_DateTime)) AS Comp_WeekDay,
	MIN(Comp_DateTime) AS Comp_RoundTime,
	COUNT(Comp_ID) AS Comp_Count
FROM
	Comp
WHERE
	Comp_Event_ID_FK = %EVENT%
	AND Comp_Cancelled = 0
	AND Comp_Dummy = 0
	AND Comp_DateTime IS NOT NULL
GROUP BY
	Comp_Race_ID_FK,
	Comp_Round