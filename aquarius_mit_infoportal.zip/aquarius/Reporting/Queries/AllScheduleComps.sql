SELECT 
	Comp_ID,
	Comp_Race_ID_FK,
	Comp_Round,
	Comp_HeatNumber,
	Comp_Label,
	Comp_GroupValue,
	Comp_DateTime,
	Comp_State,
	Comp_Number,
	CAST(Comp_Dummy AS INT) AS Comp_Dummy,
	CAST(Comp_cancelled AS INT) AS Comp_Cancelled
FROM
	Comp
	LEFT JOIN Offer ON Comp_Race_ID_FK = Offer_ID
WHERE
	Offer_Event_ID_FK = %event%
	AND Comp_DateTime IS NOT NULL
ORDER BY
	Comp_DateTime
