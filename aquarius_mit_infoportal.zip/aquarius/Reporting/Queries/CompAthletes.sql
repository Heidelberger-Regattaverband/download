SELECT DISTINCT
    Athlet_ID,
    Athlet_LastName,
    Athlet_FirstName,
    Athlet_Gender,
    YEAR(Athlet_DOB) AS Athlet_YOB,
    Athlet_Club_ID_FK,
    Athlet_ExternID_A,
    Athlet_State,
    Club_UltraAbbr
FROM
    CompEntries
    INNER JOIN Entry ON Entry_ID = CE_Entry_ID_FK
    INNER JOIN Crew ON Crew_Entry_ID_FK = Entry_ID
    INNER JOIN Athlet ON Crew_Athlete_ID_FK = Athlet_ID
    INNER JOIN Club ON Club_ID = Crew_Club_ID_FK
WHERE
    CE_Comp_ID_FK = %comp%
ORDER BY
    Athlet_LastName,
    Athlet_FirstName
