SELECT DISTINCT
    Label_ID,
    Label_Short,
    Label_Long,
    CAST(Label_IsTeam AS INT) AS Label_IsTeam,
    Nation_IOC_Code
FROM
    CompEntries
    JOIN Comp ON Comp_ID = CE_Comp_ID_FK
    JOIN EntryLabel ON EL_Entry_ID_FK = CE_Entry_ID_FK
        AND EL_RoundFrom <= Comp_Round AND EL_RoundTo >= Comp_Round
    JOIN Label ON EL_Label_ID_FK = Label_ID
    LEFT JOIN Club ON Club_ID = Label_Club_ID_FK
    LEFT JOIN Nation ON Nation_ID = Club_Nation_ID_FK
WHERE
    CE_Comp_ID_FK = %comp%