SELECT 
	CompReferee.*,
	Referee.*,
	Nation.*
FROM
	CompReferee
	LEFT JOIN Referee ON CompReferee_Referee_ID_FK = Referee_ID
	LEFT JOIN Nation ON Referee_Nation_ID_FK = Nation_ID
WHERE
	CompReferee_Comp_ID_FK = %comp%
ORDER BY
	Referee_LastName,
	Referee_FirstName
