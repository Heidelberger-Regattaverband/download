SELECT
	Result.*
FROM
	Result
	LEFT JOIN CompEntries ON Result_CE_ID_FK = CE_ID
WHERE
	CE_Comp_ID_FK = %comp%
ORDER BY
	CE_Entry_ID_FK,
	Result_SplitNr
