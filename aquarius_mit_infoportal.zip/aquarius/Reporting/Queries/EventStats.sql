SELECT

(SELECT COUNT(Offer_ID) FROM Offer WHERE Offer_Event_ID_FK = %event%) AS RaceCount,
(SELECT COUNT(Offer_ID) FROM Offer WHERE Offer_Event_ID_FK = %event% AND Offer_Driven = 0) AS CancelledRaceCount,
(SELECT COUNT(Comp_ID) FROM Comp WHERE Comp_Event_ID_FK = %event% AND Comp_Dummy = 0) AS CompCount,
(SELECT COUNT(Comp_ID) FROM Comp WHERE Comp_Event_ID_FK = %event% AND Comp_Dummy = 0 AND (Comp_Round = 64) AND (Comp_RoundCode = 'A' OR Comp_RoundCode = 'R' OR (Comp_RoundCode = 'F' AND Comp_HeatNumber = 1))) AS CompFinalCount,
(SELECT COUNT(Entry_ID) FROM Entry WHERE Entry_Event_ID_FK = %event%) AS EntryCount,
(SELECT COUNT(Entry_ID) FROM Entry JOIN EntryLabel ON EL_Entry_ID_FK = Entry_ID JOIN Label ON EL_Label_ID_FK = Label_ID AND EL_RoundFrom = 0 WHERE Entry_Event_ID_FK = %event% AND Label_IsTeam = 1) AS EntryTeamCount,
(SELECT COUNT(DISTINCT(Entry_OwnerClub_ID_FK)) FROM Entry LEFT JOIN Offer ON Entry_RAce_ID_FK = Offer_ID WHERE Offer_Event_ID_FK = %event%) AS EntryOwnerCount,
(SELECT 
		COUNT(DISTINCT(Athlet_Club_ID_FK)) 
	FROM Crew 
		LEFT JOIN Athlet ON Crew_Athlete_ID_FK = Athlet_ID
		LEFT JOIN Entry ON Crew_Entry_ID_FK = Entry_ID
	WHERE Entry_Event_ID_FK = %event%
) AS AthleteClubCount,
(SELECT 
		COUNT(DISTINCT(Crew_Athlete_ID_FK))
	FROM Crew 
		LEFT JOIN Entry ON Crew_Entry_ID_FK = Entry_ID
	WHERE Entry_Event_ID_FK = %event%
) AS AthleteCount,
(SELECT		
		COUNT(Crew_ID) 
	FROM Crew 
		LEFT JOIN Entry ON Crew_Entry_ID_FK = Entry_ID
	WHERE Entry_Event_ID_FK = %event%
) AS OccupiedSeatsCount
