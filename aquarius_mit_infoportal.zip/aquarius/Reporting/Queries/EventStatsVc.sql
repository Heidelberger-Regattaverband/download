SELECT 
	Offer_ID,
	Offer_RaceNumber,
	Offer_ShortLabel,
	Comp_GroupValue,
	COUNT(DISTINCT(Comp_ID)) AS CompCount,
	COUNT(DISTINCT(Entry_ID)) AS EntryCount,
	(BoatClass_NumRowers + BoatClass_Coxed) AS Rowers,
	COUNT(DISTINCT(Entry_ID)) * (BoatClass_NumRowers + BoatClass_Coxed) AS TotalRowers,
	COUNT(DISTINCT(Comp_ID)) * (BoatClass_NumRowers + BoatClass_Coxed) AS WinRowers
	
FROM
	Comp
	LEFT JOIN Entry ON (Comp_Race_ID_FK = Entry_Race_ID_FK AND Comp_GroupValue = Entry_GroupValue)
	LEFT JOIN Offer ON Offer_ID = Comp_Race_ID_FK
	LEFT JOIN BoatClass ON Offer_BoatClass_ID_FK = BoatClass_ID
WHERE
	(Comp_Round = 64) AND (Comp_RoundCode = 'A' OR Comp_RoundCode = 'R' OR (Comp_RoundCode = 'F' AND Comp_HeatNumber = 1))
	AND Comp_Event_ID_FK = %event%
	AND Comp_Dummy = 0	
GROUP BY
	Comp_GroupValue,
	Offer_ID,
	Offer_RaceNumber,
	Offer_ShortLabel,
	Offer_SortValue,
	BoatClass_NumRowers,
	BoatClass_Coxed
ORDER BY
	Offer_SortValue