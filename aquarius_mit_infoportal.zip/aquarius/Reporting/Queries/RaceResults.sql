SELECT
	Result.*
FROM
	Result
	LEFT JOIN CompEntries ON Result_CE_ID_FK = CE_ID
	LEFT JOIN Comp ON CE_Comp_ID_FK = Comp_ID
WHERE
	Comp_Race_ID_FK = %race%
ORDER BY
	CE_Entry_ID_FK,
	Result_SplitNr
