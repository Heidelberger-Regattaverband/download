SELECT TOP 10
	*
FROM
	(SELECT 
		Club_Abbr,
		COUNT(DISTINCT(Entry_ID)) AS Cnt,
		RANK() OVER (ORDER BY COUNT(DISTINCT(Entry_ID)) DESC) AS 'Rank'
	FROM
		Entry
		LEFT JOIN Club ON Entry_OwnerClub_ID_FK = Club_ID
	WHERE 
		Entry_Event_ID_FK = %event%
	GROUP BY
		Entry_OwnerClub_ID_FK,
		Club_Abbr) AS tmp
WHERE
	Rank <= 5
ORDER BY
	Rank
