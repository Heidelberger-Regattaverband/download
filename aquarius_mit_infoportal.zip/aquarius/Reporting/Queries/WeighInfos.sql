SELECT
	AgeClass_ID,
	AgeClass_MaxAge AS MaxAge,
	AgeClass_LW_UpperLimit AS UpperLimit,
	AgeClass_LW_AvgLimit AS AvgLimit,
	AgeClass_LW_CoxLowerLimit AS CoxLowerLimit,
	AgeClass_LW_CoxTolerance AS CoxTolerance
FROM
	AgeClass